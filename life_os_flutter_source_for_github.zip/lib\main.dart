import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const LifeOsApp());
}

class LifeOsApp extends StatefulWidget {
  const LifeOsApp({super.key});

  @override
  State<LifeOsApp> createState() => _LifeOsAppState();
}

class _LifeOsAppState extends State<LifeOsApp> {
  final LifeStore store = LifeStore();
  bool ready = false;

  @override
  void initState() {
    super.initState();
    store.load().then((_) => setState(() => ready = true));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'LIFE OS',
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xff8d99ae),
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xfff7f7f8),
            useMaterial3: true,
            fontFamily: 'Arial',
          ),
          home: ready
              ? store.profile == null
                    ? OnboardingScreen(store: store)
                    : ShellScreen(store: store)
              : const LoadingScreen(),
        );
      },
    );
  }
}

class LifeStore extends ChangeNotifier {
  static const storageKey = 'life_os_state_v1';
  UserProfile? profile;
  final List<LifeTask> tasks = [];
  final List<FitnessEntry> workouts = [];
  final List<GoalEntry> goals = [];
  final List<ExamEntry> exams = [];
  final List<GlowEntry> glowEntries = [];
  final List<BusinessEntry> businessEntries = [];
  int xp = 0;

  int get level => 1 + (xp ~/ 500);

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    if (raw == null) {
      _seed();
      return;
    }
    final data = jsonDecode(raw) as Map<String, dynamic>;
    profile = data['profile'] == null
        ? null
        : UserProfile.fromJson(data['profile']);
    xp = data['xp'] ?? 0;
    tasks
      ..clear()
      ..addAll((data['tasks'] as List? ?? []).map((e) => LifeTask.fromJson(e)));
    workouts
      ..clear()
      ..addAll(
        (data['workouts'] as List? ?? []).map((e) => FitnessEntry.fromJson(e)),
      );
    goals
      ..clear()
      ..addAll(
        (data['goals'] as List? ?? []).map((e) => GoalEntry.fromJson(e)),
      );
    exams
      ..clear()
      ..addAll(
        (data['exams'] as List? ?? []).map((e) => ExamEntry.fromJson(e)),
      );
    glowEntries
      ..clear()
      ..addAll(
        (data['glowEntries'] as List? ?? []).map((e) => GlowEntry.fromJson(e)),
      );
    businessEntries
      ..clear()
      ..addAll(
        (data['businessEntries'] as List? ?? []).map(
          (e) => BusinessEntry.fromJson(e),
        ),
      );
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(storageKey, jsonEncode(toJson()));
    notifyListeners();
  }

  Map<String, dynamic> toJson() => {
    'profile': profile?.toJson(),
    'xp': xp,
    'tasks': tasks.map((e) => e.toJson()).toList(),
    'workouts': workouts.map((e) => e.toJson()).toList(),
    'goals': goals.map((e) => e.toJson()).toList(),
    'exams': exams.map((e) => e.toJson()).toList(),
    'glowEntries': glowEntries.map((e) => e.toJson()).toList(),
    'businessEntries': businessEntries.map((e) => e.toJson()).toList(),
  };

  Future<void> importJson(String raw) async {
    final data = jsonDecode(raw) as Map<String, dynamic>;
    profile = data['profile'] == null
        ? null
        : UserProfile.fromJson(data['profile']);
    xp = data['xp'] ?? 0;
    tasks
      ..clear()
      ..addAll((data['tasks'] as List? ?? []).map((e) => LifeTask.fromJson(e)));
    workouts
      ..clear()
      ..addAll(
        (data['workouts'] as List? ?? []).map((e) => FitnessEntry.fromJson(e)),
      );
    goals
      ..clear()
      ..addAll(
        (data['goals'] as List? ?? []).map((e) => GoalEntry.fromJson(e)),
      );
    exams
      ..clear()
      ..addAll(
        (data['exams'] as List? ?? []).map((e) => ExamEntry.fromJson(e)),
      );
    glowEntries
      ..clear()
      ..addAll(
        (data['glowEntries'] as List? ?? []).map((e) => GlowEntry.fromJson(e)),
      );
    businessEntries
      ..clear()
      ..addAll(
        (data['businessEntries'] as List? ?? []).map(
          (e) => BusinessEntry.fromJson(e),
        ),
      );
    await save();
  }

  Future<void> completeTask(LifeTask task) async {
    task.done = !task.done;
    if (task.done) xp += task.priority == 'Critical' ? 80 : 50;
    await save();
  }

  Future<void> completeWorkout(FitnessEntry workout) async {
    workout.completed = !workout.completed;
    if (workout.completed) xp += 75;
    await save();
  }

  Future<void> skipWorkout(FitnessEntry workout) async {
    workout.skipped = !workout.skipped;
    if (workout.skipped) workout.completed = false;
    await save();
  }

  Future<void> completeGoal(GoalEntry goal) async {
    goal.completed = !goal.completed;
    if (goal.completed) xp += 120;
    await save();
  }

  Future<void> reset() async {
    profile = null;
    xp = 0;
    tasks.clear();
    workouts.clear();
    goals.clear();
    exams.clear();
    glowEntries.clear();
    businessEntries.clear();
    _seed();
    await save();
  }

  void _seed() {
    final today = DateTime.now();
    tasks.addAll([
      LifeTask(
        id: uid(),
        title: 'Plan the day',
        category: 'Productivity',
        priority: 'High',
        date: today,
        startHour: 8,
      ),
      LifeTask(
        id: uid(),
        title: 'Deep work block',
        category: 'Study',
        priority: 'Critical',
        date: today,
        startHour: 10,
      ),
    ]);
    workouts.addAll([
      FitnessEntry(
        id: uid(),
        title: 'Push-ups',
        muscle: 'Chest',
        level: 12,
        sets: '3 x 12',
        date: today,
      ),
      FitnessEntry(
        id: uid(),
        title: 'Squats',
        muscle: 'Legs',
        level: 10,
        sets: '3 x 15',
        date: today,
      ),
      FitnessEntry(
        id: uid(),
        title: 'Plank',
        muscle: 'Core',
        level: 8,
        sets: '3 x 45 sec',
        date: today,
      ),
    ]);
    goals.add(
      GoalEntry(
        id: uid(),
        title: '90-day transformation',
        area: 'Winter Arc',
        target: 90,
        progress: 1,
        date: today,
      ),
    );
    exams.add(
      ExamEntry(
        id: uid(),
        subject: 'Math',
        topic: 'Algebra revision',
        date: today.add(const Duration(days: 14)),
      ),
    );
    glowEntries.add(
      GlowEntry(
        id: uid(),
        title: 'Sleep before 11 PM',
        type: 'Sleep',
        date: today,
      ),
    );
    businessEntries.add(
      BusinessEntry(
        id: uid(),
        title: 'Create content idea',
        type: 'Content',
        amount: 0,
        date: today,
      ),
    );
  }
}

String uid() => DateTime.now().microsecondsSinceEpoch.toString();

DateTime onlyDate(DateTime value) =>
    DateTime(value.year, value.month, value.day);

String dateLabel(DateTime value) {
  final months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${value.day} ${months[value.month - 1]} ${value.year}';
}

class UserProfile {
  UserProfile({
    required this.name,
    required this.age,
    required this.gender,
    required this.weight,
    required this.height,
    required this.mainGoal,
    required this.arc,
  });

  String name;
  int age;
  String gender;
  double weight;
  double height;
  String mainGoal;
  String arc;

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
    name: json['name'],
    age: json['age'],
    gender: json['gender'],
    weight: (json['weight'] as num).toDouble(),
    height: (json['height'] as num).toDouble(),
    mainGoal: json['mainGoal'],
    arc: json['arc'],
  );

  Map<String, dynamic> toJson() => {
    'name': name,
    'age': age,
    'gender': gender,
    'weight': weight,
    'height': height,
    'mainGoal': mainGoal,
    'arc': arc,
  };
}

class LifeTask {
  LifeTask({
    required this.id,
    required this.title,
    required this.category,
    required this.priority,
    required this.date,
    required this.startHour,
    this.done = false,
  });

  String id;
  String title;
  String category;
  String priority;
  DateTime date;
  int startHour;
  bool done;

  factory LifeTask.fromJson(Map<String, dynamic> json) => LifeTask(
    id: json['id'],
    title: json['title'],
    category: json['category'],
    priority: json['priority'],
    date: DateTime.parse(json['date']),
    startHour: json['startHour'],
    done: json['done'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'category': category,
    'priority': priority,
    'date': date.toIso8601String(),
    'startHour': startHour,
    'done': done,
  };
}

class FitnessEntry {
  FitnessEntry({
    required this.id,
    required this.title,
    required this.muscle,
    required this.level,
    required this.sets,
    required this.date,
    this.completed = false,
    this.skipped = false,
  });

  String id;
  String title;
  String muscle;
  int level;
  String sets;
  DateTime date;
  bool completed;
  bool skipped;

  factory FitnessEntry.fromJson(Map<String, dynamic> json) => FitnessEntry(
    id: json['id'],
    title: json['title'],
    muscle: json['muscle'],
    level: json['level'],
    sets: json['sets'],
    date: DateTime.parse(json['date']),
    completed: json['completed'] ?? false,
    skipped: json['skipped'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'muscle': muscle,
    'level': level,
    'sets': sets,
    'date': date.toIso8601String(),
    'completed': completed,
    'skipped': skipped,
  };
}

class GoalEntry {
  GoalEntry({
    required this.id,
    required this.title,
    required this.area,
    required this.target,
    required this.progress,
    required this.date,
    this.completed = false,
  });

  String id;
  String title;
  String area;
  int target;
  int progress;
  DateTime date;
  bool completed;

  factory GoalEntry.fromJson(Map<String, dynamic> json) => GoalEntry(
    id: json['id'],
    title: json['title'],
    area: json['area'],
    target: json['target'],
    progress: json['progress'],
    date: DateTime.parse(json['date']),
    completed: json['completed'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'area': area,
    'target': target,
    'progress': progress,
    'date': date.toIso8601String(),
    'completed': completed,
  };
}

class ExamEntry {
  ExamEntry({
    required this.id,
    required this.subject,
    required this.topic,
    required this.date,
    this.done = false,
  });
  String id;
  String subject;
  String topic;
  DateTime date;
  bool done;

  factory ExamEntry.fromJson(Map<String, dynamic> json) => ExamEntry(
    id: json['id'],
    subject: json['subject'],
    topic: json['topic'],
    date: DateTime.parse(json['date']),
    done: json['done'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'subject': subject,
    'topic': topic,
    'date': date.toIso8601String(),
    'done': done,
  };
}

class GlowEntry {
  GlowEntry({
    required this.id,
    required this.title,
    required this.type,
    required this.date,
    this.done = false,
  });
  String id;
  String title;
  String type;
  DateTime date;
  bool done;

  factory GlowEntry.fromJson(Map<String, dynamic> json) => GlowEntry(
    id: json['id'],
    title: json['title'],
    type: json['type'],
    date: DateTime.parse(json['date']),
    done: json['done'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'type': type,
    'date': date.toIso8601String(),
    'done': done,
  };
}

class BusinessEntry {
  BusinessEntry({
    required this.id,
    required this.title,
    required this.type,
    required this.amount,
    required this.date,
    this.done = false,
  });
  String id;
  String title;
  String type;
  double amount;
  DateTime date;
  bool done;

  factory BusinessEntry.fromJson(Map<String, dynamic> json) => BusinessEntry(
    id: json['id'],
    title: json['title'],
    type: json['type'],
    amount: (json['amount'] as num).toDouble(),
    date: DateTime.parse(json['date']),
    done: json['done'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'type': type,
    'amount': amount,
    'date': date.toIso8601String(),
    'done': done,
  };
}

class LoadingScreen extends StatelessWidget {
  const LoadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.store});
  final LifeStore store;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final name = TextEditingController();
  final age = TextEditingController(text: '18');
  final weight = TextEditingController(text: '65');
  final height = TextEditingController(text: '170');
  String gender = 'Male';
  String mainGoal = 'Productivity';
  String arc = 'Winter Arc';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: FrostPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Image.asset(
                      'assets/brand/life_os_logo.png',
                      width: 140,
                      height: 140,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: Text(
                      'LIFE OS',
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Center(
                    child: Text(
                      'Build your day around discipline, fitness, goals, study, glow-up, and business.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 24),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: 'Name'),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: age,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Age'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: weight,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Weight kg',
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: height,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Height cm',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      ChoiceChip(
                        label: const Text('Male'),
                        selected: gender == 'Male',
                        onSelected: (_) => setState(() => gender = 'Male'),
                      ),
                      ChoiceChip(
                        label: const Text('Female'),
                        selected: gender == 'Female',
                        onSelected: (_) => setState(() => gender = 'Female'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField(
                    initialValue: mainGoal,
                    decoration: const InputDecoration(labelText: 'Main goal'),
                    items: [
                      'Productivity',
                      'Fitness',
                      'Study',
                      'Business',
                      'Glow-Up',
                    ].map(menuItem).toList(),
                    onChanged: (value) => setState(() => mainGoal = value!),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField(
                    initialValue: arc,
                    decoration: const InputDecoration(labelText: 'Arc mode'),
                    items: [
                      'Winter Arc',
                      'Monk Mode',
                      'Beast Mode',
                      'Sigma Mode',
                      'Exam Warrior',
                      'Business Builder',
                      'Glow-Up Arc',
                      'Discipline Arc',
                    ].map(menuItem).toList(),
                    onChanged: (value) => setState(() => arc = value!),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: () async {
                      if (name.text.trim().isEmpty) {
                        showSnack(context, 'Enter your name first.');
                        return;
                      }
                      widget.store.profile = UserProfile(
                        name: name.text.trim(),
                        age: int.tryParse(age.text) ?? 18,
                        gender: gender,
                        weight: double.tryParse(weight.text) ?? 65,
                        height: double.tryParse(height.text) ?? 170,
                        mainGoal: mainGoal,
                        arc: arc,
                      );
                      await widget.store.save();
                    },
                    icon: const Icon(Icons.bolt),
                    label: const Text('Start LIFE OS'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

DropdownMenuItem<String> menuItem(String value) =>
    DropdownMenuItem(value: value, child: Text(value));

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key, required this.store});
  final LifeStore store;

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(store: widget.store),
      TasksPage(store: widget.store),
      CalendarPage(store: widget.store),
      FitnessPage(store: widget.store),
      GoalsPage(store: widget.store),
      StudyPage(store: widget.store),
      GlowPage(store: widget.store),
      BusinessPage(store: widget.store),
      AnalyticsPage(store: widget.store),
      SettingsPage(store: widget.store),
    ];
    final items = [
      NavItem(Icons.dashboard, 'Dashboard'),
      NavItem(Icons.check_circle, 'Tasks'),
      NavItem(Icons.calendar_month, 'Calendar'),
      NavItem(Icons.fitness_center, 'Fitness'),
      NavItem(Icons.flag, 'Goals'),
      NavItem(Icons.school, 'Study'),
      NavItem(Icons.auto_awesome, 'Glow'),
      NavItem(Icons.business_center, 'Business'),
      NavItem(Icons.bar_chart, 'Analytics'),
      NavItem(Icons.settings, 'Settings'),
    ];
    final destinations = items
        .map((item) => nav(item.icon, item.label))
        .toList();

    return LayoutBuilder(
      builder: (context, size) {
        final wide = size.maxWidth >= 920;
        return Scaffold(
          body: Row(
            children: [
              if (wide)
                NavigationRail(
                  selectedIndex: index,
                  extended: true,
                  onDestinationSelected: (value) =>
                      setState(() => index = value),
                  destinations: destinations,
                ),
              Expanded(child: pages[index]),
            ],
          ),
          bottomNavigationBar: wide
              ? null
              : NavigationBar(
                  selectedIndex: index,
                  onDestinationSelected: (value) =>
                      setState(() => index = value),
                  destinations: items
                      .take(5)
                      .map(
                        (e) => NavigationDestination(
                          icon: Icon(e.icon),
                          label: e.label,
                        ),
                      )
                      .toList(),
                ),
        );
      },
    );
  }
}

NavigationRailDestination nav(IconData icon, String label) =>
    NavigationRailDestination(icon: Icon(icon), label: Text(label));

class NavItem {
  const NavItem(this.icon, this.label);
  final IconData icon;
  final String label;
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    final today = onlyDate(DateTime.now());
    final todaysTasks = store.tasks
        .where((e) => onlyDate(e.date) == today)
        .toList();
    final todaysWorkouts = store.workouts
        .where((e) => onlyDate(e.date) == today)
        .toList();
    final completed =
        todaysTasks.where((e) => e.done).length +
        todaysWorkouts.where((e) => e.completed).length;
    final total = todaysTasks.length + todaysWorkouts.length;
    return AppPage(
      title: 'Today Command Center',
      subtitle:
          '${store.profile!.name} - ${store.profile!.arc} - Level ${store.level}',
      actions: [
        FilledButton.icon(
          onPressed: () => showTaskEditor(context, store),
          icon: const Icon(Icons.add),
          label: const Text('Task'),
        ),
        FilledButton.tonalIcon(
          onPressed: () => showWorkoutEditor(context, store),
          icon: const Icon(Icons.fitness_center),
          label: const Text('Workout'),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Wrap(
            spacing: 14,
            runSpacing: 14,
            children: [
              StatCard(label: 'XP', value: '${store.xp}', icon: Icons.bolt),
              StatCard(
                label: 'Level',
                value: '${store.level}',
                icon: Icons.military_tech,
              ),
              StatCard(
                label: 'Today done',
                value: '$completed/$total',
                icon: Icons.done_all,
              ),
              StatCard(
                label: 'Skipped',
                value: '${store.workouts.where((e) => e.skipped).length}',
                icon: Icons.trending_down,
              ),
            ],
          ),
          const SizedBox(height: 18),
          SectionTitle('Schedule'),
          ...todaysTasks.map(
            (task) => TimelineTile(
              time: '${task.startHour}:00',
              title: task.title,
              subtitle: '${task.category} - ${task.priority}',
              done: task.done,
              onTap: () => store.completeTask(task),
            ),
          ),
          ...todaysWorkouts.map(
            (workout) => TimelineTile(
              time: 'Fit',
              title: workout.title,
              subtitle:
                  '${workout.sets} - ${workout.muscle} - Lv ${workout.level}',
              done: workout.completed,
              onTap: () => store.completeWorkout(workout),
            ),
          ),
          const SizedBox(height: 18),
          SectionTitle('Arc Rules'),
          FrostPanel(
            child: Text(
              arcDescription(store.profile!.arc),
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }
}

String arcDescription(String arc) {
  final descriptions = {
    'Winter Arc':
        'Train daily, wake early, avoid junk, finish one deep work block, protect sleep.',
    'Monk Mode':
        'No distractions, focused study/work blocks, clean meals, meditation, strict sleep.',
    'Beast Mode':
        'High intensity workouts, hard tasks first, aggressive goal progress.',
    'Sigma Mode':
        'Quiet execution, business progress, fitness consistency, no validation chasing.',
    'Exam Warrior':
        'Revision blocks, mock tests, topic tracking, daily study streak.',
    'Business Builder':
        'Revenue action, client/content pipeline, expense control, delivery focus.',
    'Glow-Up Arc':
        'Sleep, hygiene, skincare, confidence, posture, daily movement.',
    'Discipline Arc':
        'Do the schedule, finish missions, track misses honestly.',
  };
  return descriptions[arc] ?? descriptions['Winter Arc']!;
}

class TasksPage extends StatelessWidget {
  const TasksPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Tasks',
      subtitle: 'Plan, schedule, complete, and earn XP.',
      actions: [
        FilledButton.icon(
          onPressed: () => showTaskEditor(context, store),
          icon: const Icon(Icons.add),
          label: const Text('Add Task'),
        ),
      ],
      child: EntityList(
        empty: 'No tasks yet.',
        children: store.tasks.map((task) {
          return EntityCard(
            title: task.title,
            subtitle:
                '${dateLabel(task.date)} at ${task.startHour}:00 - ${task.category} - ${task.priority}',
            status: task.done ? 'Complete' : 'Open',
            icon: task.done ? Icons.check_circle : Icons.radio_button_unchecked,
            onTap: () => store.completeTask(task),
            onEdit: () => showTaskEditor(context, store, task: task),
            onDelete: () async {
              store.tasks.remove(task);
              await store.save();
            },
          );
        }).toList(),
      ),
    );
  }
}

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    final days = List.generate(
      14,
      (i) => onlyDate(DateTime.now().add(Duration(days: i))),
    );
    return AppPage(
      title: 'Calendar',
      subtitle:
          'Tasks, workouts, goals, exams, glow-up, and business in one timeline.',
      actions: [
        FilledButton.icon(
          onPressed: () => showTaskEditor(context, store),
          icon: const Icon(Icons.event),
          label: const Text('Schedule'),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: days.map((day) {
          final items = calendarItems(store, day);
          return FrostPanel(
            margin: const EdgeInsets.only(bottom: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  dateLabel(day),
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                if (items.isEmpty) const Text('No scheduled items.'),
                ...items.map(
                  (item) => ListTile(
                    dense: true,
                    leading: Icon(item.icon),
                    title: Text(item.title),
                    subtitle: Text(item.subtitle),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

List<CalendarItem> calendarItems(LifeStore store, DateTime day) {
  final items = <CalendarItem>[];
  items.addAll(
    store.tasks
        .where((e) => onlyDate(e.date) == day)
        .map(
          (e) => CalendarItem(
            Icons.check_circle,
            e.title,
            'Task - ${e.done ? 'complete' : 'open'}',
          ),
        ),
  );
  items.addAll(
    store.workouts
        .where((e) => onlyDate(e.date) == day)
        .map(
          (e) => CalendarItem(
            Icons.fitness_center,
            e.title,
            'Workout - ${e.completed
                ? 'complete'
                : e.skipped
                ? 'skipped'
                : 'open'}',
          ),
        ),
  );
  items.addAll(
    store.goals
        .where((e) => onlyDate(e.date) == day)
        .map(
          (e) => CalendarItem(
            Icons.flag,
            e.title,
            'Goal - ${e.progress}/${e.target}',
          ),
        ),
  );
  items.addAll(
    store.exams
        .where((e) => onlyDate(e.date) == day)
        .map((e) => CalendarItem(Icons.school, e.subject, e.topic)),
  );
  items.addAll(
    store.glowEntries
        .where((e) => onlyDate(e.date) == day)
        .map(
          (e) => CalendarItem(Icons.auto_awesome, e.title, 'Glow - ${e.type}'),
        ),
  );
  items.addAll(
    store.businessEntries
        .where((e) => onlyDate(e.date) == day)
        .map(
          (e) => CalendarItem(
            Icons.business_center,
            e.title,
            'Business - ${e.type}',
          ),
        ),
  );
  return items;
}

class CalendarItem {
  CalendarItem(this.icon, this.title, this.subtitle);
  final IconData icon;
  final String title;
  final String subtitle;
}

class FitnessPage extends StatelessWidget {
  const FitnessPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Fitness',
      subtitle: 'Exercise levels 1-100 with complete and skip analysis.',
      actions: [
        FilledButton.icon(
          onPressed: () => showWorkoutEditor(context, store),
          icon: const Icon(Icons.add),
          label: const Text('Add Exercise'),
        ),
      ],
      child: EntityList(
        empty: 'No exercises yet.',
        header: skipInsight(store),
        children: store.workouts.map((workout) {
          return EntityCard(
            title: workout.title,
            subtitle:
                '${workout.sets} - ${workout.muscle} - Level ${workout.level}',
            status: workout.completed
                ? 'Complete'
                : workout.skipped
                ? 'Skipped'
                : 'Open',
            icon: workout.completed
                ? Icons.check_circle
                : workout.skipped
                ? Icons.skip_next
                : Icons.fitness_center,
            onTap: () => store.completeWorkout(workout),
            onEdit: () => showWorkoutEditor(context, store, workout: workout),
            onDelete: () async {
              store.workouts.remove(workout);
              await store.save();
            },
            trailing: TextButton(
              onPressed: () => store.skipWorkout(workout),
              child: Text(workout.skipped ? 'Unskip' : 'Skip'),
            ),
          );
        }).toList(),
      ),
    );
  }
}

Widget skipInsight(LifeStore store) {
  final skipped = store.workouts.where((e) => e.skipped).toList();
  if (skipped.isEmpty) return const SizedBox.shrink();
  final counts = <String, int>{};
  for (final item in skipped) {
    counts[item.muscle] = (counts[item.muscle] ?? 0) + 1;
  }
  final top = counts.entries.reduce((a, b) => a.value >= b.value ? a : b);
  return FrostPanel(
    margin: const EdgeInsets.only(bottom: 12),
    child: Text(
      'Pattern: you skip ${top.key} most often (${top.value} time/s). Adjust intensity or schedule it earlier.',
    ),
  );
}

class GoalsPage extends StatelessWidget {
  const GoalsPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Goals & Missions',
      subtitle: 'Milestones, XP, badges, and arc progress.',
      actions: [
        FilledButton.icon(
          onPressed: () => showGoalEditor(context, store),
          icon: const Icon(Icons.add),
          label: const Text('Add Goal'),
        ),
      ],
      child: EntityList(
        empty: 'No goals yet.',
        children: store.goals.map((goal) {
          return EntityCard(
            title: goal.title,
            subtitle:
                '${goal.area} - ${goal.progress}/${goal.target} milestones',
            status: goal.completed
                ? 'Complete'
                : '${((goal.progress / goal.target) * 100).round()}%',
            icon: goal.completed ? Icons.emoji_events : Icons.flag,
            onTap: () => store.completeGoal(goal),
            onEdit: () => showGoalEditor(context, store, goal: goal),
            onDelete: () async {
              store.goals.remove(goal);
              await store.save();
            },
          );
        }).toList(),
      ),
    );
  }
}

class StudyPage extends StatelessWidget {
  const StudyPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return SimpleEntryPage<ExamEntry>(
      title: 'Study & Exams',
      subtitle: 'Exam countdown, topic tracking, and revision schedule.',
      store: store,
      entries: store.exams,
      addLabel: 'Add Exam',
      icon: Icons.school,
      label: (e) => e.subject,
      detail: (e) =>
          '${e.topic} - ${dateLabel(e.date)} - ${e.date.difference(DateTime.now()).inDays} days left',
      editor: showExamEditor,
      toggle: (e) {
        e.done = !e.done;
        store.xp += e.done ? 60 : 0;
        return store.save();
      },
      delete: (e) {
        store.exams.remove(e);
        return store.save();
      },
    );
  }
}

class GlowPage extends StatelessWidget {
  const GlowPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return SimpleEntryPage<GlowEntry>(
      title: 'Glow-Up',
      subtitle:
          'Sleep, mood, skincare, hygiene, meditation, and confidence missions.',
      store: store,
      entries: store.glowEntries,
      addLabel: 'Add Routine',
      icon: Icons.auto_awesome,
      label: (e) => e.title,
      detail: (e) => '${e.type} - ${dateLabel(e.date)}',
      editor: showGlowEditor,
      toggle: (e) {
        e.done = !e.done;
        store.xp += e.done ? 40 : 0;
        return store.save();
      },
      delete: (e) {
        store.glowEntries.remove(e);
        return store.save();
      },
    );
  }
}

class BusinessPage extends StatelessWidget {
  const BusinessPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    return SimpleEntryPage<BusinessEntry>(
      title: 'Business',
      subtitle: 'Income, expense, content, clients, and execution tasks.',
      store: store,
      entries: store.businessEntries,
      addLabel: 'Add Business Item',
      icon: Icons.business_center,
      label: (e) => e.title,
      detail: (e) =>
          '${e.type} - amount ${e.amount.toStringAsFixed(0)} - ${dateLabel(e.date)}',
      editor: showBusinessEditor,
      toggle: (e) {
        e.done = !e.done;
        store.xp += e.done ? 50 : 0;
        return store.save();
      },
      delete: (e) {
        store.businessEntries.remove(e);
        return store.save();
      },
    );
  }
}

class SimpleEntryPage<T> extends StatelessWidget {
  const SimpleEntryPage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.store,
    required this.entries,
    required this.addLabel,
    required this.icon,
    required this.label,
    required this.detail,
    required this.editor,
    required this.toggle,
    required this.delete,
  });

  final String title;
  final String subtitle;
  final LifeStore store;
  final List<T> entries;
  final String addLabel;
  final IconData icon;
  final String Function(T) label;
  final String Function(T) detail;
  final void Function(BuildContext, LifeStore, {T? entry}) editor;
  final Future<void> Function(T) toggle;
  final Future<void> Function(T) delete;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: title,
      subtitle: subtitle,
      actions: [
        FilledButton.icon(
          onPressed: () => editor(context, store),
          icon: const Icon(Icons.add),
          label: Text(addLabel),
        ),
      ],
      child: EntityList(
        empty: 'Nothing saved yet.',
        children: entries.map((entry) {
          return EntityCard(
            title: label(entry),
            subtitle: detail(entry),
            status: 'Tap to toggle',
            icon: icon,
            onTap: () => toggle(entry),
            onEdit: () => editor(context, store, entry: entry),
            onDelete: () => delete(entry),
          );
        }).toList(),
      ),
    );
  }
}

class AnalyticsPage extends StatelessWidget {
  const AnalyticsPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    final doneTasks = store.tasks.where((e) => e.done).length;
    final doneWorkouts = store.workouts.where((e) => e.completed).length;
    final totalActions =
        store.tasks.length +
        store.workouts.length +
        store.goals.length +
        store.exams.length +
        store.glowEntries.length +
        store.businessEntries.length;
    return AppPage(
      title: 'Analytics',
      subtitle: 'Rule-based local insights from your saved data.',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Wrap(
            spacing: 14,
            runSpacing: 14,
            children: [
              StatCard(
                label: 'Total items',
                value: '$totalActions',
                icon: Icons.inventory,
              ),
              StatCard(
                label: 'Done tasks',
                value: '$doneTasks',
                icon: Icons.task_alt,
              ),
              StatCard(
                label: 'Done workouts',
                value: '$doneWorkouts',
                icon: Icons.fitness_center,
              ),
              StatCard(label: 'XP', value: '${store.xp}', icon: Icons.bolt),
            ],
          ),
          const SizedBox(height: 18),
          SectionTitle('Insights'),
          FrostPanel(child: Text(productivityInsight(store))),
          const SizedBox(height: 12),
          skipInsight(store),
        ],
      ),
    );
  }
}

String productivityInsight(LifeStore store) {
  if (store.tasks.isEmpty) return 'Add tasks to unlock productivity insights.';
  final done = store.tasks.where((e) => e.done).length;
  final rate = ((done / store.tasks.length) * 100).round();
  if (rate >= 70) {
    return 'Strong execution: your task completion rate is $rate%. Keep protecting your schedule.';
  }
  if (rate >= 35) {
    return 'Momentum is building: your task completion rate is $rate%. Put critical work earlier in the day.';
  }
  return 'Your completion rate is $rate%. Start with fewer tasks and finish the first block before adding more.';
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key, required this.store});
  final LifeStore store;

  @override
  Widget build(BuildContext context) {
    final exportText = const JsonEncoder.withIndent(
      '  ',
    ).convert(store.toJson());
    return AppPage(
      title: 'Settings',
      subtitle: 'Profile, arc, local backup, import, and reset.',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          FrostPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${store.profile!.name} - ${store.profile!.gender}',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  '${store.profile!.mainGoal} - ${store.profile!.arc} - ${store.profile!.weight} kg - ${store.profile!.height} cm',
                ),
                const SizedBox(height: 12),
                FilledButton.tonalIcon(
                  onPressed: () => showProfileEditor(context, store),
                  icon: const Icon(Icons.person),
                  label: const Text('Edit Profile'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FrostPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Export Backup'),
                SelectableText(exportText),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => showImportDialog(context, store),
            icon: const Icon(Icons.upload_file),
            label: const Text('Import Backup JSON'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () async {
              final ok = await confirm(
                context,
                'Reset all local LIFE OS data?',
              );
              if (ok) await store.reset();
            },
            icon: const Icon(Icons.restart_alt),
            label: const Text('Reset Local Data'),
          ),
        ],
      ),
    );
  }
}

class AppPage extends StatelessWidget {
  const AppPage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.child,
    this.actions = const [],
  });
  final String title;
  final String subtitle;
  final Widget child;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xffffffff), Color(0xfff2f3f5), Color(0xffe7e9ed)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
              child: Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 12,
                runSpacing: 12,
                children: [
                  SizedBox(
                    width: 520,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/brand/life_os_mark.png',
                          width: 52,
                          height: 52,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                title,
                                style: Theme.of(context).textTheme.headlineMedium
                                    ?.copyWith(fontWeight: FontWeight.w900),
                              ),
                              Text(subtitle),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Wrap(spacing: 8, runSpacing: 8, children: actions),
                ],
              ),
            ),
            Expanded(child: child),
          ],
        ),
      ),
    );
  }
}

class FrostPanel extends StatelessWidget {
  const FrostPanel({super.key, required this.child, this.margin});
  final Widget child;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.82),
        border: Border.all(color: const Color(0xffdfe2e8)),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: Theme.of(
          context,
        ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
  });
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 190,
      child: FrostPanel(
        child: Row(
          children: [
            Icon(icon, size: 32),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(label),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class TimelineTile extends StatelessWidget {
  const TimelineTile({
    super.key,
    required this.time,
    required this.title,
    required this.subtitle,
    required this.done,
    required this.onTap,
  });
  final String time;
  final String title;
  final String subtitle;
  final bool done;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FrostPanel(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(
          child: Text(time, style: const TextStyle(fontSize: 11)),
        ),
        title: Text(
          title,
          style: TextStyle(
            decoration: done ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text(subtitle),
        trailing: Icon(
          done ? Icons.check_circle : Icons.radio_button_unchecked,
        ),
        onTap: onTap,
      ),
    );
  }
}

class EntityList extends StatelessWidget {
  const EntityList({
    super.key,
    required this.children,
    required this.empty,
    this.header,
  });
  final List<Widget> children;
  final String empty;
  final Widget? header;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (header != null) header!,
        if (children.isEmpty) FrostPanel(child: Text(empty)),
        ...children,
      ],
    );
  }
}

class EntityCard extends StatelessWidget {
  const EntityCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.icon,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
    this.trailing,
  });
  final String title;
  final String subtitle;
  final String status;
  final IconData icon;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return FrostPanel(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text('$subtitle\n$status'),
        isThreeLine: true,
        onTap: onTap,
        trailing: Wrap(
          spacing: 4,
          children: [
            if (trailing != null) trailing!,
            IconButton(
              onPressed: onEdit,
              icon: const Icon(Icons.edit),
              tooltip: 'Edit',
            ),
            IconButton(
              onPressed: onDelete,
              icon: const Icon(Icons.delete),
              tooltip: 'Delete',
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> showTaskEditor(
  BuildContext context,
  LifeStore store, {
  LifeTask? task,
}) async {
  final title = TextEditingController(text: task?.title ?? '');
  final hour = TextEditingController(text: '${task?.startHour ?? 9}');
  String category = task?.category ?? 'Productivity';
  String priority = task?.priority ?? 'Medium';
  DateTime date = task?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Task',
    [
      TextField(
        controller: title,
        decoration: const InputDecoration(labelText: 'Title'),
      ),
      DropdownButtonFormField(
        initialValue: category,
        items: [
          'Productivity',
          'Study',
          'Fitness',
          'Business',
          'Glow-Up',
          'Personal',
        ].map(menuItem).toList(),
        onChanged: (v) => category = v!,
      ),
      DropdownButtonFormField(
        initialValue: priority,
        items: ['Low', 'Medium', 'High', 'Critical'].map(menuItem).toList(),
        onChanged: (v) => priority = v!,
      ),
      TextField(
        controller: hour,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Start hour 0-23'),
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (title.text.trim().isEmpty) return false;
      if (task == null) {
        store.tasks.add(
          LifeTask(
            id: uid(),
            title: title.text.trim(),
            category: category,
            priority: priority,
            date: date,
            startHour: int.tryParse(hour.text) ?? 9,
          ),
        );
      } else {
        task
          ..title = title.text.trim()
          ..category = category
          ..priority = priority
          ..date = date
          ..startHour = int.tryParse(hour.text) ?? task.startHour;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showWorkoutEditor(
  BuildContext context,
  LifeStore store, {
  FitnessEntry? workout,
}) async {
  final title = TextEditingController(text: workout?.title ?? '');
  final sets = TextEditingController(text: workout?.sets ?? '3 x 12');
  final level = TextEditingController(text: '${workout?.level ?? 10}');
  String muscle = workout?.muscle ?? 'Full Body';
  DateTime date = workout?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Exercise',
    [
      TextField(
        controller: title,
        decoration: const InputDecoration(labelText: 'Exercise name'),
      ),
      TextField(
        controller: sets,
        decoration: const InputDecoration(labelText: 'Sets/reps/time'),
      ),
      TextField(
        controller: level,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Level 1-100'),
      ),
      DropdownButtonFormField(
        initialValue: muscle,
        items: [
          'Full Body',
          'Chest',
          'Back',
          'Legs',
          'Core',
          'Cardio',
          'Mobility',
        ].map(menuItem).toList(),
        onChanged: (v) => muscle = v!,
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (title.text.trim().isEmpty) return false;
      final parsedLevel = (int.tryParse(level.text) ?? 10).clamp(1, 100);
      if (workout == null) {
        store.workouts.add(
          FitnessEntry(
            id: uid(),
            title: title.text.trim(),
            muscle: muscle,
            level: parsedLevel,
            sets: sets.text.trim(),
            date: date,
          ),
        );
      } else {
        workout
          ..title = title.text.trim()
          ..sets = sets.text.trim()
          ..level = parsedLevel
          ..muscle = muscle
          ..date = date;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showGoalEditor(
  BuildContext context,
  LifeStore store, {
  GoalEntry? goal,
}) async {
  final title = TextEditingController(text: goal?.title ?? '');
  final target = TextEditingController(text: '${goal?.target ?? 30}');
  final progress = TextEditingController(text: '${goal?.progress ?? 0}');
  String area = goal?.area ?? store.profile!.arc;
  DateTime date = goal?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Goal',
    [
      TextField(
        controller: title,
        decoration: const InputDecoration(labelText: 'Goal title'),
      ),
      DropdownButtonFormField(
        initialValue: area,
        items: [
          'Winter Arc',
          'Fitness',
          'Study',
          'Business',
          'Glow-Up',
          'Discipline',
        ].map(menuItem).toList(),
        onChanged: (v) => area = v!,
      ),
      TextField(
        controller: target,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Target milestones'),
      ),
      TextField(
        controller: progress,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Progress'),
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (title.text.trim().isEmpty) return false;
      if (goal == null) {
        store.goals.add(
          GoalEntry(
            id: uid(),
            title: title.text.trim(),
            area: area,
            target: int.tryParse(target.text) ?? 30,
            progress: int.tryParse(progress.text) ?? 0,
            date: date,
          ),
        );
      } else {
        goal
          ..title = title.text.trim()
          ..area = area
          ..target = int.tryParse(target.text) ?? goal.target
          ..progress = int.tryParse(progress.text) ?? goal.progress
          ..date = date;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showExamEditor(
  BuildContext context,
  LifeStore store, {
  ExamEntry? entry,
}) async {
  final subject = TextEditingController(text: entry?.subject ?? '');
  final topic = TextEditingController(text: entry?.topic ?? '');
  DateTime date = entry?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Exam',
    [
      TextField(
        controller: subject,
        decoration: const InputDecoration(labelText: 'Subject'),
      ),
      TextField(
        controller: topic,
        decoration: const InputDecoration(labelText: 'Topic / revision plan'),
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (subject.text.trim().isEmpty) return false;
      if (entry == null) {
        store.exams.add(
          ExamEntry(
            id: uid(),
            subject: subject.text.trim(),
            topic: topic.text.trim(),
            date: date,
          ),
        );
      } else {
        entry
          ..subject = subject.text.trim()
          ..topic = topic.text.trim()
          ..date = date;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showGlowEditor(
  BuildContext context,
  LifeStore store, {
  GlowEntry? entry,
}) async {
  final title = TextEditingController(text: entry?.title ?? '');
  String type = entry?.type ?? 'Sleep';
  DateTime date = entry?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Glow-Up Routine',
    [
      TextField(
        controller: title,
        decoration: const InputDecoration(labelText: 'Routine / mission'),
      ),
      DropdownButtonFormField(
        initialValue: type,
        items: [
          'Sleep',
          'Skincare',
          'Mood',
          'Meditation',
          'Hygiene',
          'Confidence',
        ].map(menuItem).toList(),
        onChanged: (v) => type = v!,
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (title.text.trim().isEmpty) return false;
      if (entry == null) {
        store.glowEntries.add(
          GlowEntry(
            id: uid(),
            title: title.text.trim(),
            type: type,
            date: date,
          ),
        );
      } else {
        entry
          ..title = title.text.trim()
          ..type = type
          ..date = date;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showBusinessEditor(
  BuildContext context,
  LifeStore store, {
  BusinessEntry? entry,
}) async {
  final title = TextEditingController(text: entry?.title ?? '');
  final amount = TextEditingController(text: '${entry?.amount ?? 0}');
  String type = entry?.type ?? 'Task';
  DateTime date = entry?.date ?? DateTime.now();
  await showFormDialog(
    context,
    'Business Item',
    [
      TextField(
        controller: title,
        decoration: const InputDecoration(labelText: 'Title'),
      ),
      DropdownButtonFormField(
        initialValue: type,
        items: [
          'Task',
          'Income',
          'Expense',
          'Client',
          'Content',
          'Project',
        ].map(menuItem).toList(),
        onChanged: (v) => type = v!,
      ),
      TextField(
        controller: amount,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Amount'),
      ),
      DateButton(date: date, onChanged: (v) => date = v),
    ],
    () async {
      if (title.text.trim().isEmpty) return false;
      if (entry == null) {
        store.businessEntries.add(
          BusinessEntry(
            id: uid(),
            title: title.text.trim(),
            type: type,
            amount: double.tryParse(amount.text) ?? 0,
            date: date,
          ),
        );
      } else {
        entry
          ..title = title.text.trim()
          ..type = type
          ..amount = double.tryParse(amount.text) ?? entry.amount
          ..date = date;
      }
      await store.save();
      return true;
    },
  );
}

Future<void> showProfileEditor(BuildContext context, LifeStore store) async {
  final profile = store.profile!;
  final name = TextEditingController(text: profile.name);
  final age = TextEditingController(text: '${profile.age}');
  final weight = TextEditingController(text: '${profile.weight}');
  final height = TextEditingController(text: '${profile.height}');
  String gender = profile.gender;
  String goal = profile.mainGoal;
  String arc = profile.arc;
  await showFormDialog(
    context,
    'Profile',
    [
      TextField(
        controller: name,
        decoration: const InputDecoration(labelText: 'Name'),
      ),
      TextField(
        controller: age,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Age'),
      ),
      TextField(
        controller: weight,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Weight kg'),
      ),
      TextField(
        controller: height,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Height cm'),
      ),
      DropdownButtonFormField(
        initialValue: gender,
        items: ['Male', 'Female'].map(menuItem).toList(),
        onChanged: (v) => gender = v!,
      ),
      DropdownButtonFormField(
        initialValue: goal,
        items: [
          'Productivity',
          'Fitness',
          'Study',
          'Business',
          'Glow-Up',
        ].map(menuItem).toList(),
        onChanged: (v) => goal = v!,
      ),
      DropdownButtonFormField(
        initialValue: arc,
        items: [
          'Winter Arc',
          'Monk Mode',
          'Beast Mode',
          'Sigma Mode',
          'Exam Warrior',
          'Business Builder',
          'Glow-Up Arc',
          'Discipline Arc',
        ].map(menuItem).toList(),
        onChanged: (v) => arc = v!,
      ),
    ],
    () async {
      profile
        ..name = name.text.trim()
        ..age = int.tryParse(age.text) ?? profile.age
        ..weight = double.tryParse(weight.text) ?? profile.weight
        ..height = double.tryParse(height.text) ?? profile.height
        ..gender = gender
        ..mainGoal = goal
        ..arc = arc;
      await store.save();
      return true;
    },
  );
}

Future<void> showImportDialog(BuildContext context, LifeStore store) async {
  final controller = TextEditingController();
  await showFormDialog(
    context,
    'Import Backup JSON',
    [
      TextField(
        controller: controller,
        maxLines: 10,
        decoration: const InputDecoration(labelText: 'Paste exported JSON'),
      ),
    ],
    () async {
      try {
        await store.importJson(controller.text);
        if (context.mounted) showSnack(context, 'Backup imported.');
        return true;
      } catch (_) {
        if (context.mounted) showSnack(context, 'Invalid backup JSON.');
        return false;
      }
    },
  );
}

class DateButton extends StatefulWidget {
  const DateButton({super.key, required this.date, required this.onChanged});
  final DateTime date;
  final ValueChanged<DateTime> onChanged;

  @override
  State<DateButton> createState() => _DateButtonState();
}

class _DateButtonState extends State<DateButton> {
  late DateTime selected = widget.date;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: () async {
        final date = await showDatePicker(
          context: context,
          initialDate: selected,
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (date != null) {
          setState(() => selected = date);
          widget.onChanged(date);
        }
      },
      icon: const Icon(Icons.calendar_month),
      label: Text(dateLabel(selected)),
    );
  }
}

Future<void> showFormDialog(
  BuildContext context,
  String title,
  List<Widget> fields,
  Future<bool> Function() onSave,
) async {
  await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: fields
                  .map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: e,
                    ),
                  )
                  .toList(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final ok = await onSave();
              if (ok && context.mounted) Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      );
    },
  );
}

Future<bool> confirm(BuildContext context, String message) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Confirm'),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Confirm'),
        ),
      ],
    ),
  );
  return result ?? false;
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
