@echo off
setlocal

set FLUTTER=C:\Users\monis\Downloads\flutter\bin\flutter.bat

echo Starting LIFE OS from Flutter source...
cd /d "%~dp0"
"%FLUTTER%" pub get
"%FLUTTER%" run

pause
