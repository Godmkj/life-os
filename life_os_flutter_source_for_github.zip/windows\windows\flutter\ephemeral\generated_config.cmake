# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\monis\\Downloads\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\monis\\OneDrive\\Documents\\life goal\\life_os_flutter" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\monis\\Downloads\\flutter"
  "PROJECT_DIR=C:\\Users\\monis\\OneDrive\\Documents\\life goal\\life_os_flutter"
  "FLUTTER_ROOT=C:\\Users\\monis\\Downloads\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\monis\\OneDrive\\Documents\\life goal\\life_os_flutter\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\monis\\OneDrive\\Documents\\life goal\\life_os_flutter"
  "FLUTTER_TARGET=lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuNQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049Zjk0ZjRmYzc2Yg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ODM2NzVlZDI3Ng==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=true"
  "PACKAGE_CONFIG=C:\\Users\\monis\\OneDrive\\Documents\\life goal\\life_os_flutter\\.dart_tool\\package_config.json"
)
