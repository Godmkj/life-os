@echo off
setlocal

set FLUTTER=C:\Users\monis\Downloads\flutter\bin\flutter.bat

echo Checking LIFE OS source...
cd /d "%~dp0"
"%FLUTTER%" analyze
"%FLUTTER%" test
"%FLUTTER%" build web

echo.
echo Web build is ready at:
echo %~dp0build\web
echo.
echo Windows build needs Developer Mode:
echo start ms-settings:developers
echo.
echo Android build needs Android Studio / Android SDK.
pause
